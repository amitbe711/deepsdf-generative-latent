"""Run the N x D experiment grid: Stage 1 + both Stage-2 generators per cell.

For every (N, D) cell this script:
  1. builds N training shapes and trains the DeepSDF auto-decoder,
  2. measures reconstruction quality (Chamfer + IoU) on the trained codes,
  3. fits the Gaussian prior and trains the latent DDPM,
  4. samples each generator, decodes to point clouds, and measures generation
     quality (Coverage / MMD / 1-NN) against a held-out reference set,
  5. writes metrics JSON + loss histories + checkpoints to the output dir.

Usage:
    python scripts/run_grid.py --config configs/base.yaml --output outputs/grid
    python scripts/run_grid.py --config configs/smoke.yaml --output outputs/smoke
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.data.dataset import ShapeSDFDataset, build_shape_collection  # noqa: E402
from src.metrics.generation import (  # noqa: E402
    chamfer_matrix,
    coverage,
    minimum_matching_distance,
    one_nn_accuracy,
)
from src.metrics.reconstruction import chamfer_distance, iou_from_meshes  # noqa: E402
from src.sample import decode_mesh, decode_point_cloud  # noqa: E402
from src.train import fit_gaussian, train_ddpm, train_stage1  # noqa: E402
from src.utils import load_config, save_checkpoint, seed_everything  # noqa: E402
from src.data.sdf_sampling import sample_surface_points  # noqa: E402


def resolve_device(requested: str) -> str:
    if requested == "cuda" and not torch.cuda.is_available():
        print("[warn] CUDA requested but unavailable; falling back to CPU.")
        return "cpu"
    return requested


def build_reference_clouds(cfg, num_reference: int, surface_points: int) -> list[np.ndarray]:
    """Held-out real shapes used as the reference distribution for generation metrics."""
    ref_cfg = cfg.merge({"seed": int(cfg.seed) + 10_000})  # disjoint from training shapes
    collection = build_shape_collection(ref_cfg, num_reference)
    clouds = []
    for shape in collection:
        mesh = shape["mesh"]
        clouds.append(sample_surface_points(mesh, surface_points))
    return clouds


def evaluate_reconstruction(cfg, decoder, codes, dataset, device) -> dict[str, float]:
    max_shapes = min(int(cfg.eval.max_recon_shapes), dataset.num_shapes)
    idxs = list(range(max_shapes))
    surface = dataset.surface_clouds()
    meshes = dataset.meshes()
    res = int(cfg.eval.recon_resolution)
    iou_res = int(cfg.eval.iou_resolution)
    n_pts = int(cfg.eval.surface_points)

    cds, ious = [], []
    for i in idxs:
        z = codes.embedding.weight[i].detach()
        pred_mesh = decode_mesh(decoder, z, resolution=res, device=device)
        if pred_mesh is None or len(pred_mesh.faces) == 0:
            continue
        pred_pc = sample_surface_points(pred_mesh, n_pts)
        cds.append(chamfer_distance(pred_pc, surface[i]))
        if meshes[i] is not None:
            ious.append(iou_from_meshes(pred_mesh, meshes[i], resolution=iou_res))
    return {
        "chamfer": float(np.mean(cds)) if cds else float("nan"),
        "iou": float(np.mean(ious)) if ious else float("nan"),
        "num_evaluated": len(cds),
    }


def evaluate_generator(
    cfg, decoder, sampler_fn, reference_clouds, device
) -> dict[str, float]:
    num_gen = int(cfg.eval.num_generated)
    res = int(cfg.eval.recon_resolution)
    n_pts = int(cfg.eval.surface_points)

    z_samples = sampler_fn(num_gen)
    gen_clouds = []
    for j in range(z_samples.shape[0]):
        pc = decode_point_cloud(
            decoder, z_samples[j], num_points=n_pts, resolution=res, device=device
        )
        if pc is not None:
            gen_clouds.append(pc)

    valid_ratio = len(gen_clouds) / max(num_gen, 1)
    if len(gen_clouds) == 0:
        return {
            "coverage": float("nan"),
            "mmd": float("nan"),
            "one_nn_acc": float("nan"),
            "valid_ratio": valid_ratio,
        }

    mat = chamfer_matrix(gen_clouds, reference_clouds)
    return {
        "coverage": coverage(mat),
        "mmd": minimum_matching_distance(mat),
        "one_nn_acc": one_nn_accuracy(gen_clouds, reference_clouds),
        "valid_ratio": valid_ratio,
    }


def run_cell(cfg, num_shapes: int, latent_dim: int, output_dir: Path, device: str) -> dict:
    seed_everything(int(cfg.seed))
    tag = f"N{num_shapes}_D{latent_dim}"
    print(f"\n=== cell {tag} (device={device}) ===")
    t0 = time.time()

    collection = build_shape_collection(cfg, num_shapes)
    dataset = ShapeSDFDataset(collection)

    stage1 = train_stage1(cfg, dataset, latent_dim, device=device, progress=False)
    decoder, codes = stage1["decoder"], stage1["codes"]

    recon = evaluate_reconstruction(cfg, decoder, codes, dataset, device)
    print(f"[{tag}] reconstruction: {recon}")

    reference = build_reference_clouds(
        cfg, int(cfg.eval.num_reference), int(cfg.eval.surface_points)
    )

    results: dict = {
        "N": num_shapes,
        "D": latent_dim,
        "reconstruction": recon,
        "stage1_history": stage1["history"],
        "generators": {},
    }

    code_tensor = codes.embedding.weight.detach().cpu()

    if "gaussian" in cfg.grid.generators:
        prior = fit_gaussian(cfg, code_tensor)
        gen = torch.Generator().manual_seed(int(cfg.seed) + 7)
        metrics = evaluate_generator(
            cfg, decoder, lambda n: prior.sample(n, generator=gen), reference, device
        )
        results["generators"]["gaussian"] = metrics
        print(f"[{tag}] gaussian: {metrics}")

    if "ddpm" in cfg.grid.generators:
        ddpm_out = train_ddpm(cfg, code_tensor, device=device, progress=False)
        ddpm = ddpm_out["model"]
        metrics = evaluate_generator(
            cfg, decoder, lambda n: ddpm.sample(n, device=device).cpu(), reference, device
        )
        results["generators"]["ddpm"] = metrics
        results["ddpm_history"] = ddpm_out["history"]
        print(f"[{tag}] ddpm: {metrics}")

    results["seconds"] = time.time() - t0

    cell_dir = output_dir / tag
    save_checkpoint(
        cell_dir / "checkpoint.pt",
        {
            "config": dict(cfg),
            "decoder_state": decoder.state_dict(),
            "codes_state": codes.state_dict(),
            "latent_dim": latent_dim,
            "num_shapes": num_shapes,
        },
    )
    with open(cell_dir / "metrics.json", "w", encoding="utf-8") as handle:
        json.dump(results, handle, indent=2)

    return results


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default="configs/base.yaml")
    parser.add_argument("--output", type=str, default="outputs/grid")
    parser.add_argument("--only-N", type=int, default=None, help="run a single N")
    parser.add_argument("--only-D", type=int, default=None, help="run a single D")
    args = parser.parse_args()

    cfg = load_config(args.config)
    device = resolve_device(str(cfg.device))
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    grid_n = [args.only_N] if args.only_N else list(cfg.grid.N)
    grid_d = [args.only_D] if args.only_D else list(cfg.grid.D)

    summary = []
    for num_shapes in grid_n:
        for latent_dim in grid_d:
            results = run_cell(cfg, num_shapes, latent_dim, output_dir, device)
            summary.append(results)

    with open(output_dir / "summary.json", "w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2)
    print(f"\nWrote grid summary -> {output_dir / 'summary.json'}")


if __name__ == "__main__":
    main()
